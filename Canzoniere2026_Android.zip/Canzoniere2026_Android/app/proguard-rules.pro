# Canzoniere 2026: nessuna regola ProGuard personalizzata.
