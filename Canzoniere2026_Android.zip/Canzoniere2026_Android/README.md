# Canzoniere 2026 – App Android offline

Questa è un'app Android locale: il Canzoniere HTML è incorporato nell'APK.
Non richiede account, server o connessione Internet per funzionare.

## Creazione dell'APK dal tablet tramite GitHub
1. Crea un repository GitHub vuoto, per esempio `Canzoniere2026`.
2. Carica tutti i file di questa cartella mantenendo le cartelle.
3. Vai nella scheda **Actions** del repository.
4. Seleziona **Build APK** e premi **Run workflow**.
5. Al termine apri l'esecuzione completata e scarica l'artifact `Canzoniere-2026-APK`.
6. Estrai l'artifact e installa `app-debug.apk` sul tablet.

## Aggiornare il Canzoniere
Sostituisci:
`app/src/main/assets/canzoniere.html`
con la nuova versione HTML e avvia di nuovo la build.
